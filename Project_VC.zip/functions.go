package main

import (
	"math"
	"math/rand"
	
)

func UpdateAcceleration(currentSky Sky, i int) OrderedPair{
	// force on boid due to separation pg 3
	FSepPreyX,FSepPreyY:=SeperationFactorPrey(currentSky, i)
	FSepPredX, FSepPredY:=SeperationFactorPred(currentSky,i)
	FSepNX, FSepNY:=SeperationFactorNeutral(currentSky,i)
	newAccellX:=FSepPreyX+FSepPredX+FSepNX
	newAccellY:=FSepPreyY+FSepPredY+FSepNY
	return OrderedPair{x:newAccellX, y:newAccellY}
}

//Seperation factor should be different between prey and predator 
func SeperationFactorPrey(currentSky Sky, i int) (float64, float64){
	// force on boid due to separation pg 3
	//Fx = Cseperation *(x1-x2)/d^2
	//Fy=Cseparation*(y1-y2)/d^2
	CsepPrey:=currentSky.separationFactorPrey
	dthreshold:=currentSky.proximity
	x1:=currentSky.boids[i].position.x
	y1:=currentSky.boids[i].position.y
	SepSumX:=0.0 
	SepSumY:=0.0
    n:=0.0
	for j:=range currentSky.boids{ //for each boid other than boids[i]
		if j!=i{
			x2:=currentSky.boids[j].position.x
			y2:=currentSky.boids[j].position.y
			dx:=x2-x1
			dy:=y2-y1
			d:=math.Sqrt(dx*dx+dy*dy)
			if d<dthreshold&&d!=0{
				SepSumX+=CsepPrey*(x1-x2)/(d*d)
				SepSumY+=CsepPrey*(y1-y2)/(d*d)
                n++
			}
		}
	}
    var ForceSepX, ForceSepY float64
	if n!=0.0{
	    ForceSepX=SepSumX/(n)
	    ForceSepY=SepSumY/(n)
	}else{
		ForceSepX=0.0
		ForceSepY=0.0
	}

	return ForceSepX,ForceSepY
	
}

func SeperationFactorPred (currentSky Sky, i int) (float64, float64){
	// force on boid due to separation pg 3
	//Fx = Cseperation *(x1-x2)/d^2
	//Fy=Cseparation*(y1-y2)/d^2
	CsepPred:=currentSky.separationFactorPred
	dthreshold:=currentSky.proximity
	x1:=currentSky.boids[i].position.x
	y1:=currentSky.boids[i].position.y
	SepSumX:=0.0 
	SepSumY:=0.0
    n:=0.0
	for j:=range currentSky.boids{ //for each boid other than boids[i]
		if j!=i{
			x2:=currentSky.boids[j].position.x
			y2:=currentSky.boids[j].position.y
			dx:=x2-x1
			dy:=y2-y1
			d:=math.Sqrt(dx*dx+dy*dy)
			if d<dthreshold&&d!=0{
				SepSumX+=CsepPred*(x1-x2)/(d*d)
				SepSumY+=CsepPred*(y1-y2)/(d*d)
                n++
			}
		}
	}
    var ForceSepX, ForceSepY float64
	if n!=0.0{
	    ForceSepX=SepSumX/(n)
	    ForceSepY=SepSumY/(n)
	}else{
		ForceSepX=0.0
		ForceSepY=0.0
	}

	return ForceSepX,ForceSepY
	
}

func SeperationFactorNeutral (currentSky Sky, i int) (float64, float64){
	// force on boid due to separation pg 3
	//Fx = Cseperation *(x1-x2)/d^2
	//Fy=Cseparation*(y1-y2)/d^2
	CsepNeutral:=currentSky.separationFactorNeutral
	dthreshold:=currentSky.proximity
	x1:=currentSky.boids[i].position.x
	y1:=currentSky.boids[i].position.y
	SepSumX:=0.0 
	SepSumY:=0.0
    n:=0.0
	for j:=range currentSky.boids{ //for each boid other than boids[i]
		if j!=i{
			x2:=currentSky.boids[j].position.x
			y2:=currentSky.boids[j].position.y
			dx:=x2-x1
			dy:=y2-y1
			d:=math.Sqrt(dx*dx+dy*dy)
			if d<dthreshold&&d!=0{
				SepSumX+=CsepNeutral*(x1-x2)/(d*d)
				SepSumY+=CsepNeutral*(y1-y2)/(d*d)
                n++
			}
		}
	}
    var ForceSepX, ForceSepY float64
	if n!=0.0{
	    ForceSepX=SepSumX/(n)
	    ForceSepY=SepSumY/(n)
	}else{
		ForceSepX=0.0
		ForceSepY=0.0
	}

	return ForceSepX,ForceSepY
	
}

func UpdateVelocity(b Boid, oldAcceleration OrderedPair, maxBoidSpeed, timeStep float64) OrderedPair {
//vx(n+1)=(1/2)(ax(n)+ax(n+1))*t+vx(n)
//vy(n+1)=(1/2)(ay(n)+ay(n+1))*t+vy(n)
	oldAx:=oldAcceleration.x
	oldAy:=oldAcceleration.y
	oldVx:=b.velocity.x
	oldVy:=b.velocity.y
	newAx:=b.acceleration.x
	newAy:=b.acceleration.y
	vx:=(0.5)*(oldAx+newAx)*timeStep+oldVx
	vy:=(0.5)*(oldAy+newAy)*timeStep+oldVy
	s:=math.Sqrt(vx*vx+vy*vy)
	if s>maxBoidSpeed{
		vx=vx*(maxBoidSpeed/s)
		vy=vy*(maxBoidSpeed/s)
	}
	return OrderedPair{x:vx,y:vy}

}

func UpdatePosition(b Boid, oldAcceleration OrderedPair, oldVelocity OrderedPair, skyWidth, timeStep float64) OrderedPair {
//px(n+1)=(1/2)ax(n)*t^2+vx(n)*t+px(n)
//py(n+1)=(1/2)ay(n)*t^2+vy(n)*t+py(n)
	oldAx:=oldAcceleration.x
	oldAy:=oldAcceleration.y
	oldVx:=oldVelocity.x
	oldVy:=oldVelocity.y
    Px:=(0.5)*((oldAx)*timeStep*timeStep)+(oldVx*timeStep)+b.position.x
    Py:=(0.5)*((oldAy)*timeStep*timeStep)+(oldVy*timeStep)+b.position.y
	for Px>skyWidth{
		Px=Px-skyWidth
	}
    for Px<0{
        Px=skyWidth+Px
    }
	for Py>skyWidth{
		Py=Py-skyWidth
	}
    for Py<0{
        Py=skyWidth+Py
    }
    
	return OrderedPair{x:Px,y:Py}
}

func UpdateSky(currentSky Sky, timeStep float64) Sky {
	updatedBoids:=make([]Boid, len(currentSky.boids))
	for i,b:=range currentSky.boids{
        oldAcceleration:=b.acceleration
		newAcceleration:=UpdateAcceleration(currentSky,i)
        newVelocity:=UpdateVelocity(b, oldAcceleration,currentSky.maxBoidSpeed,timeStep)
        newPosition:=UpdatePosition(b,oldAcceleration,b.velocity,currentSky.width,timeStep)
        updatedBoids[i]=Boid{position: newPosition,velocity:newVelocity,acceleration:newAcceleration, species: b.species}
	}
	updatedSky:=Sky{
        width:            currentSky.width,
        maxBoidSpeed:     currentSky.maxBoidSpeed,
        proximity:        currentSky.proximity,
        separationFactorPrey: currentSky.separationFactorPrey,
        separationFactorPred: currentSky.separationFactorPred,
        separationFactorNeutral: currentSky.separationFactorNeutral,
        boids:            updatedBoids,
	}
	return updatedSky
}

func SimulateBoids(initialSky Sky, numGens int, timeStep float64) []Sky {
	updatedSky:=make([]Sky, numGens)
	updatedSky[0]=initialSky
	for i:=1;i<len(updatedSky);i++{
		updatedSky[i]=UpdateSky(updatedSky[i-1],timeStep)
	}
	return updatedSky
}

func InitBoids(speciesName string, count int, initialSpeed, skyWidth float64)[]Boid{
	boids := make([]Boid, count)
    s := SpeciesRegistry[speciesName]
    for i := 0; i < count; i++ {
        x := rand.Float64() * skyWidth
        y := rand.Float64() * skyWidth
        angle := rand.Float64() * 2 * math.Pi
        vx := initialSpeed * math.Cos(angle)
        vy := initialSpeed * math.Sin(angle)
        boids[i] = Boid{
            position: OrderedPair{x, y},
            velocity: OrderedPair{vx, vy},
            acceleration: OrderedPair{0.0, 0.0},
            species: s,
        }
    }
    return boids
}
