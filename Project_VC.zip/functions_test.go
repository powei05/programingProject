package main

import (
    "math"
"testing"
)
	
func TestUpdateAcceleration(t *testing.T){
	sky := Sky{
        width: 100,
        proximity: 10,
        separationFactorPrey: 1.0,
        separationFactorPred: 1.0,
        separationFactorNeutral: 1.0,
        boids: []Boid{
            {position: OrderedPair{10, 10}, species: Species{name: "rabbit", role: "prey"}},
            {position: OrderedPair{12, 10}, species: Species{name: "wolf", role: "predator"}},
        },
    }
    acc := UpdateAcceleration(sky, 0)
    if math.IsNaN(acc.x) || math.IsNaN(acc.y) {
        t.Errorf("Acceleration contains NaN: %+v", acc)
    }else{
		fmt.Println("Accleration good")
	}
}

func TestUpdateVelocity(t *testing.T) {
    b := Boid{
        velocity: OrderedPair{1, 1},
        acceleration: OrderedPair{0.5, 0.5},
    }
    oldAcc := OrderedPair{0.5, 0.5}
    v := UpdateVelocity(b, oldAcc, 2.0, 1.0)
    if v.x > 2.0 || v.y > 2.0 {
        t.Errorf("Velocity exceeds max speed: %+v", v)
    }
}

func TestUpdatePosition(t *testing.T) {
    b := Boid{
        position: OrderedPair{50, 50},
        velocity: OrderedPair{1, 1},
    }
    pos := UpdatePosition(b, OrderedPair{0.5, 0.5}, OrderedPair{1, 1}, 100, 1.0)
    if pos.x < 0 || pos.x > 100 || pos.y < 0 || pos.y > 100 {
        t.Errorf("Position out of bounds: %+v", pos)
    }
}

func TestUpdateSky(t *testing.T) {
    sky := Sky{
        width: 100,
        maxBoidSpeed: 2.0,
        proximity: 10,
        separationFactorPrey: 1.0,
        separationFactorPred: 1.0,
        separationFactorNeutral: 1.0,
        boids: []Boid{
            {position: OrderedPair{10, 10}, velocity: OrderedPair{1, 0}, acceleration: OrderedPair{0, 0}, species: Species{name: "rabbit", role: "prey"}},
        },
    }
    newSky := UpdateSky(sky, 1.0)
    if len(newSky.boids) != 1 {
        t.Errorf("Boid count mismatch")
    }
}

func TestSimulateBoids(t *testing.T) {
    sky := Sky{
        width: 100,
        maxBoidSpeed: 2.0,
        proximity: 10,
        separationFactorPrey: 1.0,
        separationFactorPred: 1.0,
        separationFactorNeutral: 1.0,
        boids: []Boid{
            {position: OrderedPair{10, 10}, velocity: OrderedPair{1, 0}, acceleration: OrderedPair{0, 0}, species: Species{name: "rabbit", role: "prey"}},
        },
    }
    sim := SimulateBoids(sky, 5, 1.0)
    if len(sim) != 5 {
        t.Errorf("Simulation length mismatch: got %d", len(sim))
    }
}

func TestInitBoids(t *testing.T) {
    boids := InitBoids("rabbit", 10, 1.0, 100)
    if len(boids) != 10 {
        t.Errorf("Boid count mismatch")
    }
    for _, b := range boids {
        if b.species.name != "rabbit" {
            t.Errorf("Species mismatch: got %s", b.species.name)
        }
    }
}

func TestGetColorForSpecies(t *testing.T) {
    color := GetColorForSpecies("wolf")
    if color.R != 100 || color.G != 100 || color.B != 100 {
        t.Errorf("Color mismatch for wolf: %+v", color)
    }
}

func TestDrawLegend(t *testing.T) {
    c := canvas.CreateNewCanvas(200, 200)
    config := Config{CanvasWidth: 200}
    DrawLegend(c, config)
}