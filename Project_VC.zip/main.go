 package main

import (
	"fmt"
    "os"
    "strconv"
    "gifhelper"
	
)

func main() {
fmt.Println("Starting Simulation!")
    
    numBoids, _ := strconv.Atoi(os.Args[1])
    skyWidth, _ := strconv.ParseFloat(os.Args[2], 64)
    initialSpeed, _ := strconv.ParseFloat(os.Args[3], 64)
    maxBoidSpeed, _ := strconv.ParseFloat(os.Args[4], 64)
    numGens, _ := strconv.Atoi(os.Args[5])
    proximity, _ := strconv.ParseFloat(os.Args[6], 64)
    separationFactorPrey, _ := strconv.ParseFloat(os.Args[7], 64)
    separationFactorPred, _ := strconv.ParseFloat(os.Args[8], 64)
    separationFactorNeutral, _ := strconv.ParseFloat(os.Args[9], 64)
    timeStep, _ := strconv.ParseFloat(os.Args[10], 64)
    canvasWidthFloat, _ := strconv.ParseFloat(os.Args[11], 64)
    canvasWidth:=int(canvasWidthFloat)
    imageFrequency,_:=strconv.Atoi(os.Args[12])

	speciesCounts:=map[string]int{
		"rabbit": Population_Rabbit,
		"sheep": Population_Sheep,
		"deer": Population_Deer,
		"wolf": Population_Wolf,
		"human": Population_Human,
	}
    initialBoids := make([]Boid, numBoids)
	for speciesName, count:=range speciesCounts{
		boids:=InitBoids(speciesName,count,initialSpeed,skyWidth)
		initialBoids=append(initialBoids,boids...)
	}

    // Create initial sky
    initialSky := Sky{
        width:            skyWidth,
        maxBoidSpeed:     maxBoidSpeed,
        proximity:        proximity,
        separationFactorPrey: separationFactorPrey,
        separationFactorPred: separationFactorPred,
        separationFactorNeutral: separationFactorNeutral,
        boids:            initialBoids,
    }


    // Run simulation
    timePoints:=SimulateBoids(initialSky, numGens+1, timeStep)

	// Then, call your simulation

	// Defining configuration settings for animation.
	config := Config{
		CanvasWidth:     canvasWidth,
		BoidSize:        5.0, // Set the boid size
		BoidColor:       Color{R: 255, G: 255, B: 255, A: 255},
		BackgroundColor: Color{R: 173, G: 216, B: 230}, // Light blue background
	}
	//for the visualization, we are only going to draw every nth board to be more efficient
	imageList := AnimateSystem(timePoints, config, imageFrequency)
	outFile := "Animal Sim"
	gifhelper.ImagesToGIF(imageList, outFile) // code is given
	fmt.Println("GIF drawn!")
	

}

//Victor- Movement/Behavior of Animals 