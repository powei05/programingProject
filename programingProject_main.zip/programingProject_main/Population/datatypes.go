package main

type Lake struct {
	Radius    float64
	MaxRadius float64     // The initial and maximum radius of the lake.
	Position  OrderedPair // Represents the center of the circle
}

type Ecosystem struct {
	Families             []Family
	Plants               []Plant
	width                float64
	weather              string // new added
	Lake                 Lake   // Add the lake to the ecosystem
	CarryingCapacity     map[string]int
	weatherChangeCounter int
}

type Species struct {
	Name              string
	Type              string
	Class             string
	GrowthRate        float64
	ContactGrowthRate float64
	energy_needs      float64
}

type Family struct {
	Size                int
	MovementSpeed       OrderedPair
	Position            OrderedPair
	MovementDirection   OrderedPair
	Acceleration        OrderedPair
	PropulsionDirection OrderedPair // The family's internal "will to move" direction
	species             Species
}

type OrderedPair struct {
	x float64
	y float64
}

type Plant struct {
	position OrderedPair
	size     float64
}

var SpeciesRegistry = map[string]Species{
	// Viable prey species with positive base growth
	"rabbit": {Name: "rabbit", Class: "prey", Type: "prey", GrowthRate: 0.03, ContactGrowthRate: -0.08, energy_needs: 0.2},
	"sheep":  {Name: "sheep", Class: "prey", Type: "prey", GrowthRate: 0.02, ContactGrowthRate: -0.06, energy_needs: 0.25},
	"deer":   {Name: "deer", Class: "prey", Type: "prey", GrowthRate: 0.01, ContactGrowthRate: -0.05, energy_needs: 0.3},

	// Viable predator that can survive with hunting
	"wolf": {Name: "wolf", Class: "predator", Type: "predator", GrowthRate: -0.02, ContactGrowthRate: 0.12},

	"human": {Name: "human", Class: "neutral", Type: "neutral", GrowthRate: 0.0, ContactGrowthRate: 0.0},
}

var initial_family_number = 3

// datatypes.go
var initialPopulations = map[string]int{
	"rabbit": 50,
	"sheep":  40,
	"deer":   30,
	// CHANGE: Start with many more wolves so they can find prey immediately.
	"wolf":  20, // Increased from 10
	"human": 2,
}

var Eating_Threshold = 30.0 // when distance is less than this value, predation can occur

const Merging_Threshold = 20.0 // when distance is less than this value, families of the same species can merge
const Smallest_Family_Size = 5 // if the family size is smaller than this value, it would merge with other families
const Max_Family_Size = 100    // if the family size is larger than this value, it would split into two
const Ecosystem_Width = 500.0  // the width of the ecosystem

const Separation_Threshold = 40.0 // Proximity threshold for separation force
const Max_Family_Speed = 40.0     // Default max family speed

const PreyPlantCoefficient = 0.12 //New
const PlantCoefficient = 0.12     //New
const consumptionRate = 0.2
const Initial_Plant_Count = 800     // Initial number of plants in the ecosystem
const Weather_Change_Interval = 100 // Weather changes every 100 steps
